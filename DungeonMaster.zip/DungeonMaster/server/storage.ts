import {
  User, InsertUser, World, InsertWorld, Region, InsertRegion,
  Location, InsertLocation, Character, InsertCharacter,
  Creature, InsertCreature, Spell, InsertSpell, LoreEntry, InsertLoreEntry
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // World methods
  getWorlds(): Promise<World[]>;
  getWorld(id: number): Promise<World | undefined>;
  createWorld(world: InsertWorld): Promise<World>;
  updateWorld(id: number, world: Partial<InsertWorld>): Promise<World | undefined>;
  deleteWorld(id: number): Promise<boolean>;

  // Region methods
  getRegions(worldId: number): Promise<Region[]>;
  getRegion(id: number): Promise<Region | undefined>;
  createRegion(region: InsertRegion): Promise<Region>;
  updateRegion(id: number, region: Partial<InsertRegion>): Promise<Region | undefined>;
  deleteRegion(id: number): Promise<boolean>;

  // Location methods
  getLocations(regionId: number): Promise<Location[]>;
  getLocationsByWorld(worldId: number): Promise<Location[]>;
  getLocation(id: number): Promise<Location | undefined>;
  createLocation(location: InsertLocation): Promise<Location>;
  updateLocation(id: number, location: Partial<InsertLocation>): Promise<Location | undefined>;
  deleteLocation(id: number): Promise<boolean>;

  // Character methods
  getCharacters(worldId: number): Promise<Character[]>;
  getCharacter(id: number): Promise<Character | undefined>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacter(id: number, character: Partial<InsertCharacter>): Promise<Character | undefined>;
  deleteCharacter(id: number): Promise<boolean>;

  // Creature methods
  getCreatures(worldId: number): Promise<Creature[]>;
  getCreature(id: number): Promise<Creature | undefined>;
  createCreature(creature: InsertCreature): Promise<Creature>;
  updateCreature(id: number, creature: Partial<InsertCreature>): Promise<Creature | undefined>;
  deleteCreature(id: number): Promise<boolean>;

  // Spell methods
  getSpells(worldId: number): Promise<Spell[]>;
  getSpell(id: number): Promise<Spell | undefined>;
  createSpell(spell: InsertSpell): Promise<Spell>;
  updateSpell(id: number, spell: Partial<InsertSpell>): Promise<Spell | undefined>;
  deleteSpell(id: number): Promise<boolean>;

  // Lore methods
  getLoreEntries(worldId: number): Promise<LoreEntry[]>;
  getLoreEntry(id: number): Promise<LoreEntry | undefined>;
  createLoreEntry(loreEntry: InsertLoreEntry): Promise<LoreEntry>;
  updateLoreEntry(id: number, loreEntry: Partial<InsertLoreEntry>): Promise<LoreEntry | undefined>;
  deleteLoreEntry(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private worlds: Map<number, World>;
  private regions: Map<number, Region>;
  private locations: Map<number, Location>;
  private characters: Map<number, Character>;
  private creatures: Map<number, Creature>;
  private spells: Map<number, Spell>;
  private loreEntries: Map<number, LoreEntry>;
  private currentIds: {
    user: number;
    world: number;
    region: number;
    location: number;
    character: number;
    creature: number;
    spell: number;
    loreEntry: number;
  };

  constructor() {
    this.users = new Map();
    this.worlds = new Map();
    this.regions = new Map();
    this.locations = new Map();
    this.characters = new Map();
    this.creatures = new Map();
    this.spells = new Map();
    this.loreEntries = new Map();
    this.currentIds = {
      user: 1,
      world: 1,
      region: 1,
      location: 1,
      character: 1,
      creature: 1,
      spell: 1,
      loreEntry: 1
    };
    
    // Create a demo world with sample data
    this.setupDemoData();
  }

  private setupDemoData() {
    // Demo user
    const demoUser: User = {
      id: this.currentIds.user++,
      username: "demouser",
      password: "password123"
    };
    this.users.set(demoUser.id, demoUser);

    // Demo world
    const demoWorld: World = {
      id: this.currentIds.world++,
      name: "The Forgotten Realms",
      description: "A land of magic, mystery, and danger. After the Great Calamity, the world was forever changed, with powerful factions vying for control over the scattered magical artifacts.",
      userId: demoUser.id,
      imageUrl: "https://images.unsplash.com/photo-1519074069444-1ba4fff66d16",
      createdAt: new Date()
    };
    this.worlds.set(demoWorld.id, demoWorld);

    // Demo regions
    const region1: Region = {
      id: this.currentIds.region++,
      name: "Eldoria",
      description: "The shining capital of the human kingdoms",
      worldId: demoWorld.id,
      imageUrl: "https://images.unsplash.com/photo-1589182337358-0a66813de530",
      type: "Capital"
    };
    
    const region2: Region = {
      id: this.currentIds.region++,
      name: "Mystic Forest",
      description: "Ancient woodland home to elves and fey creatures",
      worldId: demoWorld.id,
      imageUrl: "https://images.unsplash.com/photo-1596239880360-0e1a84c1d0b5",
      type: "Forest"
    };
    
    const region3: Region = {
      id: this.currentIds.region++,
      name: "Dragon's Peak",
      description: "Mountain range inhabited by fearsome dragons",
      worldId: demoWorld.id,
      imageUrl: "https://images.unsplash.com/photo-1577493340887-b7bfff550145",
      type: "Mountain"
    };
    
    this.regions.set(region1.id, region1);
    this.regions.set(region2.id, region2);
    this.regions.set(region3.id, region3);

    // Demo locations
    const location1: Location = {
      id: this.currentIds.location++,
      name: "Eldoria Castle",
      description: "The majestic castle at the heart of Eldoria",
      regionId: region1.id,
      imageUrl: "https://images.unsplash.com/photo-1533154683836-84ea7a0bc310",
      locationType: "Castle",
      x: 300,
      y: 250,
      markerType: "standard"
    };
    
    const location2: Location = {
      id: this.currentIds.location++,
      name: "Ancient Grove",
      description: "Sacred grove at the center of the Mystic Forest",
      regionId: region2.id,
      imageUrl: "https://images.unsplash.com/photo-1448375240586-882707db888b",
      locationType: "Sacred Site",
      x: 600,
      y: 400,
      markerType: "quest"
    };
    
    const location3: Location = {
      id: this.currentIds.location++,
      name: "Dragon's Lair",
      description: "The treacherous lair of the Ancient Red Dragon",
      regionId: region3.id,
      imageUrl: "https://images.unsplash.com/photo-1577493340887-b7bfff550145",
      locationType: "Lair",
      x: 400,
      y: 500,
      markerType: "danger"
    };
    
    this.locations.set(location1.id, location1);
    this.locations.set(location2.id, location2);
    this.locations.set(location3.id, location3);

    // Demo characters
    const character1: Character = {
      id: this.currentIds.character++,
      name: "Elindra Moonwhisper",
      worldId: demoWorld.id,
      regionId: region1.id,
      locationId: location1.id,
      description: "Royal advisor to the Eldorian court and master of arcane secrets.",
      appearance: "Tall and slender with silver hair and violet eyes. Always dressed in elegant blue robes adorned with silver embroidery.",
      personality: "Calm and collected, but fiercely protective of arcane knowledge. Cautious with strangers but loyal to allies.",
      abilities: ["Master Diviner", "Arcane Scholar", "Telepathic Communication"],
      imageUrl: "https://images.unsplash.com/photo-1589182337358-0a66813de530",
      race: "Elf",
      characterType: "npc"
    };
    
    const character2: Character = {
      id: this.currentIds.character++,
      name: "Thoric Ironhammer",
      worldId: demoWorld.id,
      regionId: region3.id,
      locationId: null,
      description: "Master blacksmith and keeper of ancient forging techniques.",
      appearance: "Stout with a thick red beard adorned with metal clasps. Burns and scars cover his muscular arms from years of smithing.",
      personality: "Gruff but fair. Values quality craftsmanship above all else and detests shortcuts in work.",
      abilities: ["Master Blacksmith", "Enchanted Forging", "Dwarven Resilience"],
      imageUrl: "https://images.unsplash.com/photo-1566577739112-5180d4bf9390",
      race: "Dwarf",
      characterType: "npc"
    };
    
    const character3: Character = {
      id: this.currentIds.character++,
      name: "Vash Nightblade",
      worldId: demoWorld.id,
      regionId: region1.id,
      locationId: null,
      description: "Shadow assassin and leader of the Crimson Brotherhood.",
      appearance: "Slender and agile with a face usually hidden behind a dark mask. Wears form-fitting leather armor with crimson accents.",
      personality: "Calculating and patient. Shows no mercy to those who stand in his way, but follows a strict personal code.",
      abilities: ["Shadow Step", "Poisoncraft", "Enhanced Stealth"],
      imageUrl: "https://images.unsplash.com/photo-1553356084-58ef4a67b2a7",
      race: "Human",
      characterType: "villain"
    };
    
    const character4: Character = {
      id: this.currentIds.character++,
      name: "Lyra Greenleaf",
      worldId: demoWorld.id,
      regionId: region2.id,
      locationId: location2.id,
      description: "Healer and guardian of the Mystic Forest's ancient secrets.",
      appearance: "Graceful with honey-colored hair adorned with small flowers. Wears flowing green and brown robes made of natural fibers.",
      personality: "Gentle and wise beyond her years. Takes her duty as forest guardian seriously but shows compassion to all living things.",
      abilities: ["Nature Magic", "Advanced Healing", "Animal Communication"],
      imageUrl: "https://images.unsplash.com/photo-1594736797933-d0501ba2fe65",
      race: "Half-Elf",
      characterType: "ally"
    };
    
    this.characters.set(character1.id, character1);
    this.characters.set(character2.id, character2);
    this.characters.set(character3.id, character3);
    this.characters.set(character4.id, character4);

    // Demo creatures
    const creature1: Creature = {
      id: this.currentIds.creature++,
      name: "Ancient Red Dragon",
      worldId: demoWorld.id,
      regionId: region3.id,
      imageUrl: "https://images.unsplash.com/photo-1577493340887-b7bfff550145",
      description: "Terrifying dragons with scales of crimson, capable of devastating fire breath attacks.",
      creatureType: "Dragon",
      rarity: "legendary",
      challengeRating: "24",
      armorClass: 22,
      hitPoints: "546 (28d20 + 252)",
      speed: "40 ft., climb 40 ft., fly 80 ft.",
      abilities: { STR: 30, DEX: 10, CON: 29, INT: 18, WIS: 15, CHA: 23 },
      specialAttacks: ["Fire Breath (Recharge 5-6): 90-foot cone, 24d6 fire damage"],
      elementType: "Fire"
    };
    
    const creature2: Creature = {
      id: this.currentIds.creature++,
      name: "Mystic Forest Wolf",
      worldId: demoWorld.id,
      regionId: region2.id,
      imageUrl: "https://images.unsplash.com/photo-1568198473832-b6b0f46328c1",
      description: "Enchanted wolves with glowing green eyes that hunt in packs through the ancient forests.",
      creatureType: "Beast",
      rarity: "common",
      challengeRating: "3",
      armorClass: 13,
      hitPoints: "45 (6d10 + 12)",
      speed: "50 ft.",
      abilities: { STR: 16, DEX: 15, CON: 14, INT: 6, WIS: 12, CHA: 8 },
      specialAttacks: ["Pack Tactics: Advantage on attack rolls against a creature if at least one ally is within 5 feet."],
      elementType: "Nature"
    };
    
    const creature3: Creature = {
      id: this.currentIds.creature++,
      name: "Shadowfell Stalker",
      worldId: demoWorld.id,
      regionId: null,
      imageUrl: "https://images.unsplash.com/photo-1596239880360-0e1a84c1d0b5",
      description: "Ethereal creatures born from the Shadowfell that drain the life force of their victims.",
      creatureType: "Undead",
      rarity: "rare",
      challengeRating: "8",
      armorClass: 16,
      hitPoints: "120 (16d8 + 48)",
      speed: "30 ft., fly 30 ft. (hover)",
      abilities: { STR: 16, DEX: 18, CON: 16, INT: 10, WIS: 14, CHA: 16 },
      specialAttacks: [
        "Shadow Stealth: Can hide in dim light or darkness with a bonus to Dexterity (Stealth) checks.",
        "Life Drain: Melee attacks drain life force, reducing target's max HP."
      ],
      elementType: "Shadow"
    };
    
    this.creatures.set(creature1.id, creature1);
    this.creatures.set(creature2.id, creature2);
    this.creatures.set(creature3.id, creature3);

    // Demo spells
    const spell1: Spell = {
      id: this.currentIds.spell++,
      name: "Arcane Blast",
      worldId: demoWorld.id,
      level: 3,
      school: "Evocation",
      castingTime: "1 action",
      range: "60 feet",
      components: "V, S, M (a pinch of powdered silver)",
      duration: "Instantaneous",
      description: "A beam of brilliant blue energy erupts from your fingertips, dealing 6d6 force damage to a target within range. The target must make a Dexterity saving throw, taking half damage on a success.",
      imageUrl: "https://images.unsplash.com/photo-1563116155-5c496c8e1a99",
      creatorCharacterId: 1 // Elindra Moonwhisper
    };
    
    const spell2: Spell = {
      id: this.currentIds.spell++,
      name: "Nature's Shield",
      worldId: demoWorld.id,
      level: 2,
      school: "Abjuration",
      castingTime: "1 action",
      range: "Self",
      components: "V, S, M (a leaf from an ancient tree)",
      duration: "1 hour",
      description: "Bark-like growth covers your skin, granting you +3 to your AC for the duration. Additionally, you gain resistance to non-magical bludgeoning, piercing, and slashing damage.",
      imageUrl: "https://images.unsplash.com/photo-1501886676591-d50b57e4211f",
      creatorCharacterId: 4 // Lyra Greenleaf
    };
    
    const spell3: Spell = {
      id: this.currentIds.spell++,
      name: "Crimson Binding",
      worldId: demoWorld.id,
      level: 5,
      school: "Necromancy",
      castingTime: "1 action",
      range: "30 feet",
      components: "V, S, M (a drop of blood)",
      duration: "Concentration, up to 1 minute",
      description: "Tendrils of crimson energy erupt from the ground, wrapping around a creature you can see within range. The target must make a Strength saving throw or be restrained and take 3d6 necrotic damage at the start of each of its turns.",
      imageUrl: "https://images.unsplash.com/photo-1585489869354-332fe4575342",
      creatorCharacterId: 3 // Vash Nightblade
    };
    
    this.spells.set(spell1.id, spell1);
    this.spells.set(spell2.id, spell2);
    this.spells.set(spell3.id, spell3);

    // Demo lore entries
    const lore1: LoreEntry = {
      id: this.currentIds.loreEntry++,
      title: "The Great Calamity",
      worldId: demoWorld.id,
      content: "Two centuries ago, a cataclysmic magical event known as the Great Calamity tore through the fabric of reality, reshaping the landscape and unleashing ancient powers long forgotten. Many believe it was caused by a conflict between the gods, while others suspect it was the result of mortal hubris in the pursuit of forbidden knowledge.",
      category: "Historical Events",
      imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23"
    };
    
    const lore2: LoreEntry = {
      id: this.currentIds.loreEntry++,
      title: "The Order of the Silver Hand",
      worldId: demoWorld.id,
      content: "A noble organization of paladins and clerics who swear to protect the innocent and bring light to the darkest corners of the realm. Founded after the Great Calamity, they seek to restore order and faith to a fractured world. Their symbol—a silver hand holding a radiant sun—represents their commitment to guiding others out of darkness.",
      category: "Factions & Organizations",
      imageUrl: "https://images.unsplash.com/photo-1599689868230-9a146ba26535"
    };
    
    const lore3: LoreEntry = {
      id: this.currentIds.loreEntry++,
      title: "The Crimson Brotherhood",
      worldId: demoWorld.id,
      content: "A secretive network of assassins and thieves who operate in the shadows of major cities. Though feared by many, they adhere to a strict code and only accept contracts against those they deem deserving of judgment. Their true motives remain unknown, though rumors suggest they seek ancient artifacts scattered during the Great Calamity.",
      category: "Factions & Organizations",
      imageUrl: "https://images.unsplash.com/photo-1518002171953-a080ee817e1f"
    };
    
    this.loreEntries.set(lore1.id, lore1);
    this.loreEntries.set(lore2.id, lore2);
    this.loreEntries.set(lore3.id, lore3);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentIds.user++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // World methods
  async getWorlds(): Promise<World[]> {
    return Array.from(this.worlds.values());
  }

  async getWorld(id: number): Promise<World | undefined> {
    return this.worlds.get(id);
  }

  async createWorld(insertWorld: InsertWorld): Promise<World> {
    const id = this.currentIds.world++;
    const world: World = { ...insertWorld, id, createdAt: new Date() };
    this.worlds.set(id, world);
    return world;
  }

  async updateWorld(id: number, updates: Partial<InsertWorld>): Promise<World | undefined> {
    const world = this.worlds.get(id);
    if (!world) return undefined;
    
    const updatedWorld: World = { ...world, ...updates };
    this.worlds.set(id, updatedWorld);
    return updatedWorld;
  }

  async deleteWorld(id: number): Promise<boolean> {
    return this.worlds.delete(id);
  }

  // Region methods
  async getRegions(worldId: number): Promise<Region[]> {
    return Array.from(this.regions.values()).filter(
      (region) => region.worldId === worldId
    );
  }

  async getRegion(id: number): Promise<Region | undefined> {
    return this.regions.get(id);
  }

  async createRegion(insertRegion: InsertRegion): Promise<Region> {
    const id = this.currentIds.region++;
    const region: Region = { ...insertRegion, id };
    this.regions.set(id, region);
    return region;
  }

  async updateRegion(id: number, updates: Partial<InsertRegion>): Promise<Region | undefined> {
    const region = this.regions.get(id);
    if (!region) return undefined;
    
    const updatedRegion: Region = { ...region, ...updates };
    this.regions.set(id, updatedRegion);
    return updatedRegion;
  }

  async deleteRegion(id: number): Promise<boolean> {
    return this.regions.delete(id);
  }

  // Location methods
  async getLocations(regionId: number): Promise<Location[]> {
    return Array.from(this.locations.values()).filter(
      (location) => location.regionId === regionId
    );
  }

  async getLocationsByWorld(worldId: number): Promise<Location[]> {
    const regions = await this.getRegions(worldId);
    const regionIds = regions.map(region => region.id);
    return Array.from(this.locations.values()).filter(
      (location) => regionIds.includes(location.regionId)
    );
  }

  async getLocation(id: number): Promise<Location | undefined> {
    return this.locations.get(id);
  }

  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const id = this.currentIds.location++;
    const location: Location = { ...insertLocation, id };
    this.locations.set(id, location);
    return location;
  }

  async updateLocation(id: number, updates: Partial<InsertLocation>): Promise<Location | undefined> {
    const location = this.locations.get(id);
    if (!location) return undefined;
    
    const updatedLocation: Location = { ...location, ...updates };
    this.locations.set(id, updatedLocation);
    return updatedLocation;
  }

  async deleteLocation(id: number): Promise<boolean> {
    return this.locations.delete(id);
  }

  // Character methods
  async getCharacters(worldId: number): Promise<Character[]> {
    return Array.from(this.characters.values()).filter(
      (character) => character.worldId === worldId
    );
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    return this.characters.get(id);
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const id = this.currentIds.character++;
    const character: Character = { ...insertCharacter, id };
    this.characters.set(id, character);
    return character;
  }

  async updateCharacter(id: number, updates: Partial<InsertCharacter>): Promise<Character | undefined> {
    const character = this.characters.get(id);
    if (!character) return undefined;
    
    const updatedCharacter: Character = { ...character, ...updates };
    this.characters.set(id, updatedCharacter);
    return updatedCharacter;
  }

  async deleteCharacter(id: number): Promise<boolean> {
    return this.characters.delete(id);
  }

  // Creature methods
  async getCreatures(worldId: number): Promise<Creature[]> {
    return Array.from(this.creatures.values()).filter(
      (creature) => creature.worldId === worldId
    );
  }

  async getCreature(id: number): Promise<Creature | undefined> {
    return this.creatures.get(id);
  }

  async createCreature(insertCreature: InsertCreature): Promise<Creature> {
    const id = this.currentIds.creature++;
    const creature: Creature = { ...insertCreature, id };
    this.creatures.set(id, creature);
    return creature;
  }

  async updateCreature(id: number, updates: Partial<InsertCreature>): Promise<Creature | undefined> {
    const creature = this.creatures.get(id);
    if (!creature) return undefined;
    
    const updatedCreature: Creature = { ...creature, ...updates };
    this.creatures.set(id, updatedCreature);
    return updatedCreature;
  }

  async deleteCreature(id: number): Promise<boolean> {
    return this.creatures.delete(id);
  }

  // Spell methods
  async getSpells(worldId: number): Promise<Spell[]> {
    return Array.from(this.spells.values()).filter(
      (spell) => spell.worldId === worldId
    );
  }

  async getSpell(id: number): Promise<Spell | undefined> {
    return this.spells.get(id);
  }

  async createSpell(insertSpell: InsertSpell): Promise<Spell> {
    const id = this.currentIds.spell++;
    const spell: Spell = { ...insertSpell, id };
    this.spells.set(id, spell);
    return spell;
  }

  async updateSpell(id: number, updates: Partial<InsertSpell>): Promise<Spell | undefined> {
    const spell = this.spells.get(id);
    if (!spell) return undefined;
    
    const updatedSpell: Spell = { ...spell, ...updates };
    this.spells.set(id, updatedSpell);
    return updatedSpell;
  }

  async deleteSpell(id: number): Promise<boolean> {
    return this.spells.delete(id);
  }

  // Lore methods
  async getLoreEntries(worldId: number): Promise<LoreEntry[]> {
    return Array.from(this.loreEntries.values()).filter(
      (loreEntry) => loreEntry.worldId === worldId
    );
  }

  async getLoreEntry(id: number): Promise<LoreEntry | undefined> {
    return this.loreEntries.get(id);
  }

  async createLoreEntry(insertLoreEntry: InsertLoreEntry): Promise<LoreEntry> {
    const id = this.currentIds.loreEntry++;
    const loreEntry: LoreEntry = { ...insertLoreEntry, id };
    this.loreEntries.set(id, loreEntry);
    return loreEntry;
  }

  async updateLoreEntry(id: number, updates: Partial<InsertLoreEntry>): Promise<LoreEntry | undefined> {
    const loreEntry = this.loreEntries.get(id);
    if (!loreEntry) return undefined;
    
    const updatedLoreEntry: LoreEntry = { ...loreEntry, ...updates };
    this.loreEntries.set(id, updatedLoreEntry);
    return updatedLoreEntry;
  }

  async deleteLoreEntry(id: number): Promise<boolean> {
    return this.loreEntries.delete(id);
  }
}

export const storage = new MemStorage();
