import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import { z } from "zod";
import {
  insertWorldSchema,
  insertRegionSchema,
  insertLocationSchema,
  insertCharacterSchema,
  insertCreatureSchema,
  insertSpellSchema,
  insertLoreEntrySchema
} from "@shared/schema";

const memory = multer.memoryStorage();
const sanitizeInput = (input: string): string => {
  return input.replace(/[<>]/g, '').trim();
};

const upload = multer({ 
  storage: memory,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
    files: 1
  },
  fileFilter: (_req, file, callback) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    const allowedExtensions = ['.jpg', '.jpeg', '.png', '.gif'];
    
    if (!allowedTypes.includes(file.mimetype) || 
        !allowedExtensions.includes(path.extname(file.originalname).toLowerCase())) {
      return callback(new Error('Invalid file type. Only JPG, PNG, and GIF files are allowed'));
    }
    callback(null, true);
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // World routes
  app.get('/api/worlds', async (_req: Request, res: Response) => {
    try {
      const worlds = await storage.getWorlds();
      res.json(worlds);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch worlds' });
    }
  });

  app.get('/api/worlds/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const world = await storage.getWorld(id);
      if (!world) {
        return res.status(404).json({ message: 'World not found' });
      }
      
      res.json(world);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch world' });
    }
  });

  app.post('/api/worlds', async (req: Request, res: Response) => {
    try {
      const worldData = insertWorldSchema.parse(req.body);
      const newWorld = await storage.createWorld(worldData);
      res.status(201).json(newWorld);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid world data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create world' });
    }
  });

  app.put('/api/worlds/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const worldData = insertWorldSchema.partial().parse(req.body);
      const updatedWorld = await storage.updateWorld(id, worldData);
      
      if (!updatedWorld) {
        return res.status(404).json({ message: 'World not found' });
      }
      
      res.json(updatedWorld);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid world data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to update world' });
    }
  });

  app.delete('/api/worlds/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const success = await storage.deleteWorld(id);
      if (!success) {
        return res.status(404).json({ message: 'World not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete world' });
    }
  });

  // Region routes
  app.get('/api/worlds/:worldId/regions', async (req: Request, res: Response) => {
    try {
      const worldId = parseInt(req.params.worldId);
      if (isNaN(worldId)) {
        return res.status(400).json({ message: 'Invalid world ID format' });
      }
      
      const regions = await storage.getRegions(worldId);
      res.json(regions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch regions' });
    }
  });

  app.get('/api/regions/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const region = await storage.getRegion(id);
      if (!region) {
        return res.status(404).json({ message: 'Region not found' });
      }
      
      res.json(region);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch region' });
    }
  });

  app.post('/api/regions', async (req: Request, res: Response) => {
    try {
      const regionData = insertRegionSchema.parse(req.body);
      const newRegion = await storage.createRegion(regionData);
      res.status(201).json(newRegion);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid region data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create region' });
    }
  });

  app.put('/api/regions/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const regionData = insertRegionSchema.partial().parse(req.body);
      const updatedRegion = await storage.updateRegion(id, regionData);
      
      if (!updatedRegion) {
        return res.status(404).json({ message: 'Region not found' });
      }
      
      res.json(updatedRegion);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid region data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to update region' });
    }
  });

  app.delete('/api/regions/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const success = await storage.deleteRegion(id);
      if (!success) {
        return res.status(404).json({ message: 'Region not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete region' });
    }
  });

  // Location routes
  app.get('/api/regions/:regionId/locations', async (req: Request, res: Response) => {
    try {
      const regionId = parseInt(req.params.regionId);
      if (isNaN(regionId)) {
        return res.status(400).json({ message: 'Invalid region ID format' });
      }
      
      const locations = await storage.getLocations(regionId);
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch locations' });
    }
  });

  app.get('/api/worlds/:worldId/locations', async (req: Request, res: Response) => {
    try {
      const worldId = parseInt(req.params.worldId);
      if (isNaN(worldId)) {
        return res.status(400).json({ message: 'Invalid world ID format' });
      }
      
      const locations = await storage.getLocationsByWorld(worldId);
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch locations' });
    }
  });

  app.get('/api/locations/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const location = await storage.getLocation(id);
      if (!location) {
        return res.status(404).json({ message: 'Location not found' });
      }
      
      res.json(location);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch location' });
    }
  });

  app.post('/api/locations', async (req: Request, res: Response) => {
    try {
      const locationData = insertLocationSchema.parse(req.body);
      const newLocation = await storage.createLocation(locationData);
      res.status(201).json(newLocation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid location data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create location' });
    }
  });

  app.put('/api/locations/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const locationData = insertLocationSchema.partial().parse(req.body);
      const updatedLocation = await storage.updateLocation(id, locationData);
      
      if (!updatedLocation) {
        return res.status(404).json({ message: 'Location not found' });
      }
      
      res.json(updatedLocation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid location data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to update location' });
    }
  });

  app.delete('/api/locations/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const success = await storage.deleteLocation(id);
      if (!success) {
        return res.status(404).json({ message: 'Location not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete location' });
    }
  });

  // Character routes
  app.get('/api/worlds/:worldId/characters', async (req: Request, res: Response) => {
    try {
      const worldId = parseInt(req.params.worldId);
      if (isNaN(worldId)) {
        return res.status(400).json({ message: 'Invalid world ID format' });
      }
      
      const characters = await storage.getCharacters(worldId);
      res.json(characters);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch characters' });
    }
  });

  app.get('/api/characters/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const character = await storage.getCharacter(id);
      if (!character) {
        return res.status(404).json({ message: 'Character not found' });
      }
      
      res.json(character);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch character' });
    }
  });

  app.post('/api/characters', async (req: Request, res: Response) => {
    try {
      const characterData = insertCharacterSchema.parse(req.body);
      const newCharacter = await storage.createCharacter(characterData);
      res.status(201).json(newCharacter);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid character data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create character' });
    }
  });

  app.put('/api/characters/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const characterData = insertCharacterSchema.partial().parse(req.body);
      const updatedCharacter = await storage.updateCharacter(id, characterData);
      
      if (!updatedCharacter) {
        return res.status(404).json({ message: 'Character not found' });
      }
      
      res.json(updatedCharacter);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid character data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to update character' });
    }
  });

  app.delete('/api/characters/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const success = await storage.deleteCharacter(id);
      if (!success) {
        return res.status(404).json({ message: 'Character not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete character' });
    }
  });

  // Creature routes
  app.get('/api/worlds/:worldId/creatures', async (req: Request, res: Response) => {
    try {
      const worldId = parseInt(req.params.worldId);
      if (isNaN(worldId)) {
        return res.status(400).json({ message: 'Invalid world ID format' });
      }
      
      const creatures = await storage.getCreatures(worldId);
      res.json(creatures);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch creatures' });
    }
  });

  app.get('/api/creatures/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const creature = await storage.getCreature(id);
      if (!creature) {
        return res.status(404).json({ message: 'Creature not found' });
      }
      
      res.json(creature);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch creature' });
    }
  });

  app.post('/api/creatures', async (req: Request, res: Response) => {
    try {
      const creatureData = insertCreatureSchema.parse(req.body);
      const newCreature = await storage.createCreature(creatureData);
      res.status(201).json(newCreature);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid creature data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create creature' });
    }
  });

  app.put('/api/creatures/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const creatureData = insertCreatureSchema.partial().parse(req.body);
      const updatedCreature = await storage.updateCreature(id, creatureData);
      
      if (!updatedCreature) {
        return res.status(404).json({ message: 'Creature not found' });
      }
      
      res.json(updatedCreature);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid creature data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to update creature' });
    }
  });

  app.delete('/api/creatures/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const success = await storage.deleteCreature(id);
      if (!success) {
        return res.status(404).json({ message: 'Creature not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete creature' });
    }
  });

  // Spell routes
  app.get('/api/worlds/:worldId/spells', async (req: Request, res: Response) => {
    try {
      const worldId = parseInt(req.params.worldId);
      if (isNaN(worldId)) {
        return res.status(400).json({ message: 'Invalid world ID format' });
      }
      
      const spells = await storage.getSpells(worldId);
      res.json(spells);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch spells' });
    }
  });

  app.get('/api/spells/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const spell = await storage.getSpell(id);
      if (!spell) {
        return res.status(404).json({ message: 'Spell not found' });
      }
      
      res.json(spell);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch spell' });
    }
  });

  app.post('/api/spells', async (req: Request, res: Response) => {
    try {
      const spellData = insertSpellSchema.parse(req.body);
      const newSpell = await storage.createSpell(spellData);
      res.status(201).json(newSpell);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid spell data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create spell' });
    }
  });

  app.put('/api/spells/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const spellData = insertSpellSchema.partial().parse(req.body);
      const updatedSpell = await storage.updateSpell(id, spellData);
      
      if (!updatedSpell) {
        return res.status(404).json({ message: 'Spell not found' });
      }
      
      res.json(updatedSpell);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid spell data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to update spell' });
    }
  });

  app.delete('/api/spells/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const success = await storage.deleteSpell(id);
      if (!success) {
        return res.status(404).json({ message: 'Spell not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete spell' });
    }
  });

  // Lore routes
  app.get('/api/worlds/:worldId/lore', async (req: Request, res: Response) => {
    try {
      const worldId = parseInt(req.params.worldId);
      if (isNaN(worldId)) {
        return res.status(400).json({ message: 'Invalid world ID format' });
      }
      
      const loreEntries = await storage.getLoreEntries(worldId);
      res.json(loreEntries);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch lore entries' });
    }
  });

  app.get('/api/lore/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const loreEntry = await storage.getLoreEntry(id);
      if (!loreEntry) {
        return res.status(404).json({ message: 'Lore entry not found' });
      }
      
      res.json(loreEntry);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch lore entry' });
    }
  });

  app.post('/api/lore', async (req: Request, res: Response) => {
    try {
      const loreData = insertLoreEntrySchema.parse(req.body);
      const newLoreEntry = await storage.createLoreEntry(loreData);
      res.status(201).json(newLoreEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid lore data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create lore entry' });
    }
  });

  app.put('/api/lore/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const loreData = insertLoreEntrySchema.partial().parse(req.body);
      const updatedLoreEntry = await storage.updateLoreEntry(id, loreData);
      
      if (!updatedLoreEntry) {
        return res.status(404).json({ message: 'Lore entry not found' });
      }
      
      res.json(updatedLoreEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid lore data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to update lore entry' });
    }
  });

  app.delete('/api/lore/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const success = await storage.deleteLoreEntry(id);
      if (!success) {
        return res.status(404).json({ message: 'Lore entry not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete lore entry' });
    }
  });

  // Image upload
  app.post('/api/upload-image', upload.single('image'), (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }
      
      // In a real application, we'd save this to a storage service and return the URL
      // For this demo, we'll simulate a URL return
      const fileName = `${Date.now()}-${req.file.originalname}`;
      const fileUrl = `https://example.com/uploads/${fileName}`;
      
      res.json({ 
        url: fileUrl,
        success: true
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to upload image' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
