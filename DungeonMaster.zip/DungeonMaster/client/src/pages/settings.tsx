import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import FantasyBorder from "@/components/ui/fantasy-border";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChromePicker } from 'react-color';
import { useToast } from '@/hooks/use-toast';

// Font options
const fontOptions = [
  { value: 'cinzel', label: 'Cinzel (Default)' },
  { value: 'medieval-sharp', label: 'Medieval Sharp' },
  { value: 'lora', label: 'Lora' },
  { value: 'merriweather', label: 'Merriweather' },
  { value: 'spectral', label: 'Spectral' }
];

// Background options
const backgroundOptions = [
  { value: 'parchment', label: 'Parchment' },
  { value: 'forest', label: 'Forest' },
  { value: 'castle', label: 'Castle' },
  { value: 'mountains', label: 'Mountains' },
  { value: 'custom', label: 'Custom URL' },
  { value: 'none', label: 'None (Solid Color)' }
];

export default function Settings() {
  const { toast } = useToast();
  const [primaryColor, setPrimaryColor] = useState('#7B2D26');
  const [accentColor, setAccentColor] = useState('#D4AF37');
  const [backgroundColor, setBackgroundColor] = useState('#F5E6C8');
  const [backgroundImage, setBackgroundImage] = useState('parchment');
  const [customBgUrl, setCustomBgUrl] = useState('');
  const [headerFont, setHeaderFont] = useState('cinzel');
  const [bodyFont, setBodyFont] = useState('lora');
  const [showColorPicker, setShowColorPicker] = useState<string | null>(null);

  // Example function to apply settings (would need actual implementation)
  const applySettings = () => {
    // Here we'd want to update a theme context or localStorage settings
    const root = document.documentElement;
    
    // Convert hex to hsl for CSS variables
    const applyColor = (hex: string, variableName: string) => {
      // This is a simplification - a real implementation would convert properly
      root.style.setProperty(`--${variableName}`, hex);
    };
    
    // Apply colors
    applyColor(primaryColor, 'primary');
    applyColor(accentColor, 'accent');
    applyColor(backgroundColor, 'background');
    
    // Apply fonts
    document.body.className = `font-${bodyFont}`;
    
    // Apply background
    if (backgroundImage === 'none') {
      document.body.style.backgroundImage = 'none';
    } else if (backgroundImage === 'custom' && customBgUrl) {
      document.body.style.backgroundImage = `url(${customBgUrl})`;
    } else {
      // We'd use a mapping of presets to actual URLs
      const bgMapping: Record<string, string> = {
        'parchment': 'https://images.unsplash.com/photo-1581441363689-1be2df97e484?auto=format&fit=crop&w=1000&q=80',
        'forest': 'https://images.unsplash.com/photo-1502759683299-cdcd6974244f?auto=format&fit=crop&w=1000&q=80',
        'castle': 'https://images.unsplash.com/photo-1596578190493-9d77d54ba293?auto=format&fit=crop&w=1000&q=80',
        'mountains': 'https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?auto=format&fit=crop&w=1000&q=80',
      };
      document.body.style.backgroundImage = `url(${bgMapping[backgroundImage] || bgMapping['parchment']})`;
    }
    
    toast({
      title: "Settings Applied",
      description: "Your customization settings have been applied.",
    });
  };

  const resetSettings = () => {
    // Reset to default values
    setPrimaryColor('#7B2D26');
    setAccentColor('#D4AF37');
    setBackgroundColor('#F5E6C8');
    setBackgroundImage('parchment');
    setCustomBgUrl('');
    setHeaderFont('cinzel');
    setBodyFont('lora');
    
    // Apply the defaults
    applySettings();
    
    toast({
      title: "Settings Reset",
      description: "All settings have been reset to default values.",
    });
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold font-cinzel text-primary mb-2">Customize Your World</h1>
        <p className="text-foreground/80">Personalize the appearance of your worldbuilding toolset</p>
      </div>
      
      <FantasyBorder className="mb-6">
        <Tabs defaultValue="appearance" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="data">Data Management</TabsTrigger>
          </TabsList>
          
          <TabsContent value="appearance" className="p-4">
            <div className="grid gap-6 md:grid-cols-2">
              {/* Colors Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Colors</CardTitle>
                  <CardDescription>Customize the color scheme of your world</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Primary Color */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="primary-color">Primary Color</Label>
                      <div 
                        className="w-8 h-8 rounded-full cursor-pointer border border-border"
                        style={{ backgroundColor: primaryColor }}
                        onClick={() => setShowColorPicker(showColorPicker === 'primary' ? null : 'primary')}
                      />
                    </div>
                    {showColorPicker === 'primary' && (
                      <div className="absolute z-10">
                        <div 
                          className="fixed inset-0" 
                          onClick={() => setShowColorPicker(null)}
                        />
                        <ChromePicker 
                          color={primaryColor} 
                          onChange={(color) => setPrimaryColor(color.hex)} 
                        />
                      </div>
                    )}
                  </div>
                  
                  {/* Accent Color */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="accent-color">Accent Color</Label>
                      <div 
                        className="w-8 h-8 rounded-full cursor-pointer border border-border"
                        style={{ backgroundColor: accentColor }}
                        onClick={() => setShowColorPicker(showColorPicker === 'accent' ? null : 'accent')}
                      />
                    </div>
                    {showColorPicker === 'accent' && (
                      <div className="absolute z-10">
                        <div 
                          className="fixed inset-0" 
                          onClick={() => setShowColorPicker(null)}
                        />
                        <ChromePicker 
                          color={accentColor} 
                          onChange={(color) => setAccentColor(color.hex)} 
                        />
                      </div>
                    )}
                  </div>
                  
                  {/* Background Color */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="background-color">Background Color</Label>
                      <div 
                        className="w-8 h-8 rounded-full cursor-pointer border border-border"
                        style={{ backgroundColor: backgroundColor }}
                        onClick={() => setShowColorPicker(showColorPicker === 'background' ? null : 'background')}
                      />
                    </div>
                    {showColorPicker === 'background' && (
                      <div className="absolute z-10">
                        <div 
                          className="fixed inset-0" 
                          onClick={() => setShowColorPicker(null)}
                        />
                        <ChromePicker 
                          color={backgroundColor} 
                          onChange={(color) => setBackgroundColor(color.hex)} 
                        />
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              {/* Fonts & Background Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Fonts & Background</CardTitle>
                  <CardDescription>Choose fonts and background settings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Header Font */}
                  <div className="space-y-2">
                    <Label htmlFor="header-font">Header Font</Label>
                    <Select value={headerFont} onValueChange={setHeaderFont}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select header font" />
                      </SelectTrigger>
                      <SelectContent>
                        {fontOptions.map(font => (
                          <SelectItem key={font.value} value={font.value}>
                            {font.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* Body Font */}
                  <div className="space-y-2">
                    <Label htmlFor="body-font">Body Font</Label>
                    <Select value={bodyFont} onValueChange={setBodyFont}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select body font" />
                      </SelectTrigger>
                      <SelectContent>
                        {fontOptions.map(font => (
                          <SelectItem key={font.value} value={font.value}>
                            {font.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* Background Image */}
                  <div className="space-y-2">
                    <Label htmlFor="background-image">Background Image</Label>
                    <Select value={backgroundImage} onValueChange={setBackgroundImage}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select background" />
                      </SelectTrigger>
                      <SelectContent>
                        {backgroundOptions.map(bg => (
                          <SelectItem key={bg.value} value={bg.value}>
                            {bg.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* Custom Background URL (only show if 'custom' is selected) */}
                  {backgroundImage === 'custom' && (
                    <div className="space-y-2">
                      <Label htmlFor="custom-bg-url">Custom Background URL</Label>
                      <Input 
                        id="custom-bg-url" 
                        value={customBgUrl} 
                        onChange={(e) => setCustomBgUrl(e.target.value)}
                        placeholder="https://example.com/image.jpg" 
                      />
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            <div className="flex justify-center mt-6 space-x-4">
              <Button onClick={resetSettings} variant="outline">
                Reset to Defaults
              </Button>
              <Button onClick={applySettings}>
                Apply Settings
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="data" className="p-4">
            <Card>
              <CardHeader>
                <CardTitle>Data Management</CardTitle>
                <CardDescription>Export and import your world data</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold">Export World Data</h3>
                  <p className="text-sm text-foreground/70">
                    Download all data from your current world as a JSON file for backup or transfer.
                  </p>
                  <Button className="mt-2">
                    Export Current World
                  </Button>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold">Import World Data</h3>
                  <p className="text-sm text-foreground/70">
                    Import a previously exported world data file.
                  </p>
                  <div className="flex flex-col md:flex-row gap-2 mt-2">
                    <Input id="world-import" type="file" accept=".json" />
                    <Button>
                      Import
                    </Button>
                  </div>
                </div>
                
                <div className="border-t pt-4 mt-6">
                  <h3 className="text-lg font-semibold text-destructive">Danger Zone</h3>
                  <p className="text-sm text-foreground/70 mb-4">
                    These actions cannot be undone. Be careful!
                  </p>
                  
                  <Button variant="destructive">
                    Delete Current World
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </FantasyBorder>
      
      <div className="mt-8">
        <h2 className="text-2xl font-cinzel font-bold text-primary mb-4">Preview</h2>
        <FantasyBorder className="bg-card p-6">
          <h3 className="text-xl font-cinzel font-bold mb-2">Style Preview</h3>
          <p className="mb-4">This is how your text and UI elements will appear with the current settings.</p>
          <div className="flex flex-wrap gap-2 mb-4">
            <Button>Primary Button</Button>
            <Button variant="outline">Outline Button</Button>
            <Button variant="ghost">Ghost Button</Button>
          </div>
          <div className="rounded-sm bg-accent/20 p-4 border border-accent/30">
            <p className="text-sm">This is a sample text block with your current styling.</p>
          </div>
        </FantasyBorder>
      </div>
    </div>
  );
}