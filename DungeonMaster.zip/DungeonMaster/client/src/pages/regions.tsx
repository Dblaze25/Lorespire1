import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import type { World, Region } from '@shared/schema';
import WorldSelector from '@/components/WorldSelector';
import { Button } from '@/components/ui/button';
import { Plus, ChevronRight, Search, Map as MapIcon } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { AddRegionModal } from '@/modals/AddRegionModal';
import FantasyBorder from '@/components/ui/fantasy-border';
import { Link, useLocation } from 'wouter';

export default function Regions() {
  const [currentWorldId, setCurrentWorldId] = useState<number>(1);
  const [isAddRegionModalOpen, setIsAddRegionModalOpen] = useState(false);
  const [selectedRegionId, setSelectedRegionId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const queryClient = useQueryClient();

  const { data: worlds } = useQuery({
    queryKey: ['/api/worlds'],
  });

  const { data: regions, isLoading: regionsLoading } = useQuery({
    queryKey: [`/api/worlds/${currentWorldId}/regions`],
    enabled: !!currentWorldId,
  });

  const { data: locations } = useQuery({
    queryKey: [`/api/worlds/${currentWorldId}/locations`],
    enabled: !!currentWorldId,
  });

  // For URL query params
  const [location] = useLocation();
  
  // Set initial world ID once data is loaded
  useEffect(() => {
    if (worlds && worlds.length > 0 && !currentWorldId) {
      setCurrentWorldId(worlds[0].id);
    }
  }, [worlds, currentWorldId]);
  
  // Parse URL for highlighted region
  useEffect(() => {
    if (!regions) return;
    
    // Extract regionId from URL if present
    const queryPart = location.includes('?') ? location.split('?')[1] : '';
    const urlParams = new URLSearchParams(queryPart);
    const highlightParam = urlParams.get('highlight');
    
    if (highlightParam) {
      const regionId = parseInt(highlightParam);
      if (!isNaN(regionId)) {
        // Find the region in our loaded regions
        const region = regions.find((r: Region) => r.id === regionId);
        if (region) {
          setSelectedRegionId(regionId);
        }
      }
    }
  }, [regions, location]);

  const handleWorldChange = (worldId: number) => {
    setCurrentWorldId(worldId);
    setSelectedRegionId(null);
  };

  const handleRegionAdded = () => {
    queryClient.invalidateQueries({ queryKey: [`/api/worlds/${currentWorldId}/regions`] });
  };

  const filteredRegions = regions?.filter((region: Region) => 
    region.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    region.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const regionLocations = (regionId: number) => {
    return locations?.filter((location) => location.regionId === regionId) || [];
  };

  const selectedRegion = regions?.find((r: Region) => r.id === selectedRegionId);

  return (
    <>
      <WorldSelector currentWorldId={currentWorldId} onWorldChange={handleWorldChange} />

      <FantasyBorder className="bg-card p-6 mb-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-cinzel font-bold text-primary">Regions</h1>
          <Button 
            className="bg-accent text-primary hover:bg-accent/90 flex items-center"
            onClick={() => setIsAddRegionModalOpen(true)}
          >
            <Plus className="h-4 w-4 mr-1" />
            Add Region
          </Button>
        </div>

        <div className="relative mb-6 max-w-md">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-foreground/50" />
          <Input 
            className="pl-8 bg-secondary border-accent/30"
            placeholder="Search regions..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {regionsLoading ? (
            <div className="text-center py-10 col-span-full">Loading regions...</div>
          ) : filteredRegions?.length === 0 ? (
            <div className="text-center py-10 col-span-full">
              <p className="mb-4 text-foreground/70">No regions found.</p>
              <Button 
                className="bg-accent text-primary hover:bg-accent/90"
                onClick={() => setIsAddRegionModalOpen(true)}
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Region
              </Button>
            </div>
          ) : (
            filteredRegions?.map((region: Region) => (
              <div 
                key={region.id}
                className="bg-secondary hover:bg-secondary/90 transition rounded-sm overflow-hidden cursor-pointer"
                onClick={() => setSelectedRegionId(region.id)}
              >
                {region.imageUrl && (
                  <div className="h-40 overflow-hidden">
                    <img 
                      src={region.imageUrl}
                      alt={region.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div className="p-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-cinzel font-semibold text-lg">{region.name}</h3>
                    <span className="text-xs opacity-70 bg-primary/10 px-2 py-1 rounded-sm">{region.type}</span>
                  </div>
                  <p className="text-sm mt-2 line-clamp-2">{region.description}</p>
                  <div className="flex justify-between items-center mt-3 text-xs">
                    <span>{regionLocations(region.id)?.length || 0} locations</span>
                    <Link href={`/locations?regionId=${region.id}`}>
                      <Button variant="ghost" size="sm" className="flex items-center p-0 h-6">
                        <span className="mr-1">View Locations</span>
                        <ChevronRight className="h-3 w-3" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </FantasyBorder>

      {selectedRegion && (
        <FantasyBorder className="bg-card p-6">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h2 className="text-3xl font-cinzel font-bold text-primary">{selectedRegion.name}</h2>
              <p className="text-sm text-foreground/70 mt-1">{selectedRegion.type}</p>
            </div>
            <Link href={`/locations?regionId=${selectedRegion.id}`}>
              <Button className="bg-accent text-primary hover:bg-accent/90">
                View Locations
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-cinzel text-primary mb-4">Description</h3>
              <p className="text-foreground/80">{selectedRegion.description}</p>

              <div className="mt-6">
                <h3 className="text-xl font-cinzel text-primary mb-4">Details</h3>
                <div className="bg-secondary/50 p-4 rounded-sm">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-foreground/70">Region Type</p>
                      <p className="font-medium">{selectedRegion.type || "Unknown"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-foreground/70">Locations</p>
                      <p className="font-medium">{regionLocations(selectedRegion.id)?.length || 0}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {selectedRegion.imageUrl ? (
              <div className="h-[300px] overflow-hidden rounded-sm">
                <img 
                  src={selectedRegion.imageUrl}
                  alt={selectedRegion.name}
                  className="w-full h-full object-cover"
                />
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-[300px] bg-secondary/30 rounded-sm">
                <MapIcon className="w-16 h-16 text-foreground/30 mb-4" />
                <p className="text-foreground/70">No image available</p>
              </div>
            )}
          </div>
        </FantasyBorder>
      )}

      <AddRegionModal 
        isOpen={isAddRegionModalOpen} 
        onClose={() => setIsAddRegionModalOpen(false)}
        onRegionAdded={handleRegionAdded}
        worldId={currentWorldId}
      />
    </>
  );
}
